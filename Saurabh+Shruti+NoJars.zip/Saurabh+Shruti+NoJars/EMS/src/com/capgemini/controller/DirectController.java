package com.capgemini.controller;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;












import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.daos.EmployeeDao;
import com.capgemini.entities.Employee;
import com.capgemini.entities.User;
import com.capgemini.exceptions.EMS_Exception;
import com.capgemini.services.EmployeeService;
import com.capgemini.services.UserService;


@Controller
public class DirectController {
	
	
	
	
	
	/****references****/
	@Autowired
	EmployeeService empService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	EmployeeDao empDao;
	
	
	
	
	
	/*************************************************/
	
	@RequestMapping(value="/toEMSNews")
	public String getNewsPage()
	{
		return"EMS_News";
	}
	
	
	@RequestMapping(value="/toContactPage")
	public String getContactPage()
	{
		return "EMS_Contact";
	}
	
	@RequestMapping(value="/toAboutPage")
	public String getAboutPage()
	{
		return "EMS_About";
	}
	
	
	
	/*************************************************/
	

	
	/****handlers****/
	@RequestMapping(value="/index")
	public String getHomePage()
	{
		return"EMS_HomePage";
	}
	
	@RequestMapping(value="/login")
	public String goToLogin(Model model)
	{
		model.addAttribute("user", new User());
		return "EMS_LoginPage";
	}
	
	@RequestMapping(value="/postLogin")
	@Scope("session")
	public String afterLoginGoTo(@ModelAttribute("user") User user,HttpSession session, HttpServletRequest request)
	{
		User validUser;
		String str = "EMS_LoginPage";
		session = request.getSession(true);
		try {
			validUser = userService.usrCheck(user.getUserName(), user.getUserPassword());
			
		} catch (EMS_Exception e) {
			request.setAttribute("msg", "Invalid user name or password");
			return "Ems_errorPage";
		
		}
		
		switch (validUser.getUserType()) {
		
			
			case "admin":
				session.setAttribute("usrType", "admin");
				session.setAttribute("usrName", validUser.getUserName());
				str =  "EMS_AdminMainPage";
				break;
			case "user":
				session.setAttribute("usrType", "user");
				session.setAttribute("usrName", validUser.getUserName());
				str =  "EMS_User_Main_Page";
				break;
		}
		return str;
	}
	
	@RequestMapping(value="/logoutPage",method=RequestMethod.GET)
	public String afterLogout(HttpSession session, HttpServletRequest request) {
		session = request.getSession(false);
		session.invalidate();
		return "redirect:/login.html";
	}
	

	
	
	/****************************************************************/	
	
	/****add employee handlers****/
	@RequestMapping(value="/addEmpForm")
	public String addGradeTFrom(Model model){

		model.addAttribute("emp", new Employee());
		model.addAttribute("grades",empDao.fetchGrades());
		return "addEmpForm";
	}	
	
	@RequestMapping(value="/postAddEmp",method=RequestMethod.POST)
	public String addEmployee(@ModelAttribute("emp") @Valid Employee emp, BindingResult result){
		
		if(result.hasErrors()){
			return "addEmpForm";
		}
		else {
		emp = formatDate(emp);		//at the end method is defined
		empService.addEmployee(emp);
		return "redirect:/listemp.html";
		}
	}

	
	
	
	
	/************************************************************/	
	
	/****list employee handlers****/
	@RequestMapping(value="/listemp")
	public String listAllEmployee(Model model){
		
		model.addAttribute("empList", empService.getAllEmployee());
		return "listAll";
	}
	
	
	
	/*******************************************************/
	
	
	
	/***update handlers***/	
	
	@RequestMapping(value="/updateEmpById")
	public String forUpdateByIdOnEntry(Model model){
	
		model.addAttribute("emp",new Employee());
		return "updateForm";						//form which will enter id
	}
	
	@RequestMapping(value="/toUpdateById",method=RequestMethod.POST)
	public String forUpdateByIdOnEntryFromForm(@ModelAttribute("emp")Employee emp,Model model , HttpServletRequest request) {
		
		
		try {
			emp = empService.getEmployeeById(emp.getEmp_Id());
		} catch (EMS_Exception e) {
			// TODO Auto-generated catch block
			request.setAttribute("msg", "Invalid user name or password");
			return "Ems_errorPage";
		}
		
		String dob = emp.getEmp_Date_of_Birth().toString();
		String doj = emp.getEmp_Date_of_Joining().toString();
		
		emp.setEmp_Date_of_Birth1(changeDateFormat(dob));
		emp.setEmp_Date_of_Joining1(changeDateFormat(doj));
		
		model.addAttribute("emp", emp);
		
		return "postUpdateForm";
	}
	


	@RequestMapping(value="/toUpdate")
	public String forUpdateFromLink(@RequestParam("id")int id, Model model,HttpServletRequest request){
		
		Employee emp = new Employee();
		try {
			emp = empService.getEmployeeById(id);
		} catch (EMS_Exception e) {
			// TODO Auto-generated catch block
			request.setAttribute("msg", "Wrong Id");
			return "Ems_errorPage";
		}
		
		String dob = emp.getEmp_Date_of_Birth().toString();
		String doj = emp.getEmp_Date_of_Joining().toString();
		
		emp.setEmp_Date_of_Birth1(changeDateFormat(dob));
		emp.setEmp_Date_of_Joining1(changeDateFormat(doj));
			
		model.addAttribute("emp", emp);
		
		return "postUpdateForm";
	}

	
	
	/***both updates; by link and by id will come here***/
	@RequestMapping(value="/afterUpdate",method=RequestMethod.POST)
	public String finalUpdate(@ModelAttribute("emp") Employee emp){
		emp = formatDate(emp);
		
		empService.updateEmployee(emp);
		
		return "EMS_AdminMainPage";
		
	}
	
	
	
	
	/********************************************************************************/
	/*
	 * This is the User Portion of the Controller
	 * 
	 */
	
	
	/***Id search***/
	@RequestMapping(value = "/goToSearchById")
	public String toIdSearch(Model model)
	{
		model.addAttribute("emp",new Employee());
		return "EMS_Search_For_User_By_Id";
	}
	
	/***First Name Search***/
	@RequestMapping(value="/goToSearchByFirstName")
	public String toFirstNameSearch(Model model) {

		model.addAttribute("emp",new Employee());
		return "EMS_Search_For_User_By_First_Name";
	}
	

	/***Last Name Search***/
	@RequestMapping(value="/goToSearchByLastName")
	public String toLastNameSearch(Model model) {

		model.addAttribute("emp",new Employee());
		return "EMS_Search_For_User_By_Last_Name";
	}
	
	
	
	/***All search display on this jsp***/
	@RequestMapping(value = "/FindForUser")
	public String fromIdSearch(@ModelAttribute("emp") Employee emp , Model model,HttpServletRequest req)
	{
		emp = searchEmp(emp);
		
		if(emp == null) {
			req.setAttribute("msg", "NO result found");
			System.out.println("no result");
			/***redirect to error page with message of no such employee found***/
			return "Ems_errorPage";
		}
		
		model.addAttribute("emp", emp);
		String dob = emp.getEmp_Date_of_Birth().toString();
		String doj = emp.getEmp_Date_of_Joining().toString();
		
		emp.setEmp_Date_of_Birth1(changeDateFormat(dob));
		emp.setEmp_Date_of_Joining1(changeDateFormat(doj));
		
		return "searchResults";
		
	}
	
	
	
	/********************************************************************************/
	
	
	
/*	
	*//*****to delete an entry based on id***//*
	@RequestMapping("/deleteEmp")
	public String delEmp(Model model){
		model.addAttribute("employee", new Employee());
		return "deleteForm";
	}
	
	@RequestMapping(value="/postDel")
	public String postDelEmp(@ModelAttribute("employee") Employee emp){
		emp = empService.getEmployeeById(emp);
		empService.delEmployee(emp);
		return "index";
	}
	*/
	
	
	
	
	

	
	
	private Employee searchEmp(Employee emp) {
		if(emp.getEmp_Id() != 0) {
			try {
				emp = empService.getEmployeeById(emp.getEmp_Id());
			} catch (EMS_Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return emp;
		}
		else if(emp.getEmp_First_Name() != null) {
			//return empService.getEmployeeByFirstName(emp.getEmp_First_Name());
		}
		else if(emp.getEmp_Last_Name() != null) {
			//return empService.getEmployeeByLastName(emp.getEmp_Last_Name());
		}
		
		return null;
	}
	
	
	
	
/****************private methods for date formatting and parsing************************************************/	
	
	@SuppressWarnings("finally")
	private String changeDateFormat(String date) {
		
		DateFormat in = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat out = new SimpleDateFormat("dd-MM-yyyy");
		String parsedDate = null;
		
		try {
			Date dateToParse=in.parse(date);
			parsedDate = out.format(dateToParse);		
		}
		catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			return parsedDate;
		}
	}

	/****Method to format date from string to date****/
	private Employee formatDate(Employee emp) {
		
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		Date parseDob = null;
		Date parseDoj = null;
		
		try {
			parseDob = df.parse(emp.getEmp_Date_of_Birth1());
			parseDoj = df.parse(emp.getEmp_Date_of_Joining1());
		}
		catch (Exception e1) {
			e1.printStackTrace();
		}

		java.sql.Date dateDob = new java.sql.Date(parseDob.getTime());
		java.sql.Date dateDoj = new java.sql.Date(parseDoj.getTime());
		
		emp.setEmp_Date_of_Birth(dateDob);
		emp.setEmp_Date_of_Joining(dateDoj);
		
		return emp;
	}
	
	
	/* 
	 * This part is under maintainence
	 * 
	 */
	
	@RequestMapping(value="/sentToMaintainencePage")
	public String sentToMaintainence()
	{
		return "Ems_under_maintainence";
	}
	
}
