package com.capgemini.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.entities.User;
import com.capgemini.exceptions.EMS_Exception;

@Repository
public class UserDaoImpl implements UserDao {

	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public User usrCheck(String usrName, String usrPass) throws EMS_Exception {
		User user = null; 
		TypedQuery<User> queryForUserCheck = entitymanager.createQuery("SELECT u FROM User u WHERE u.userName = '"+usrName+"' "
				+ "AND u.userPassword = '"+usrPass+"' " ,User.class);
		//queryForUserCheck.setParameter("usrName", usrName);
		//queryForUserCheck.setParameter("usrPass", usrPass);
		try {
			user= (User) queryForUserCheck.getSingleResult();
		}
		catch (Exception e) {
			throw new EMS_Exception("Invalid user name and Id");
		}
		
	return user;	
	}

}
