package com.capgemini.daos;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.entities.Employee;
import com.capgemini.entities.GradeMaster;
import com.capgemini.exceptions.EMS_Exception;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	
	@PersistenceContext
	EntityManager entitymanager;

	/*
	 * This method of DAO will display all the employees
	 * 
	 * */
	@Override
	public List<Employee> getAllEmployee() {
		TypedQuery<Employee> query = entitymanager.createQuery("SELECT s FROM Employee s", Employee.class);
		return query.getResultList();
	}
	
/*******************************************************************************************/
	
	/*
	 * This method of DAO will add the employee to the DataBase
	 * 
	 * */
	@Override
	public void addEmployee(Employee emp) {

		entitymanager.persist(emp);
		entitymanager.flush();
		
	}
	
/******************************************************************************************/
	
	/*
	 * This method of DAO will fetch the Grades from the DataBase
	 * 
	 * */
	
	@Override
	public List<String> fetchGrades() {
		TypedQuery<GradeMaster> query = entitymanager.createQuery("SELECT g FROM GradeMaster g", GradeMaster.class);
		List<String> grades=new ArrayList<String>(); 
		for (GradeMaster grade : query.getResultList()) {
			grades.add(grade.getGrade_Code());
		}
		return grades;
	}
	
/**
 * @throws EMS_Exception *****************************************************************************************/
	/*
	 * This method of DAO will fetch the Employee from the DataBase using ID
	 * 
	 * */
	
	@Override
	public Employee getEmployeeById(int id) throws EMS_Exception {
		Employee emp = new Employee();
		
		try
		{emp = entitymanager.find(Employee.class, id);}
		catch(Exception e)
		{
			throw new EMS_Exception("no employee with that id is found");
		}
	
		return emp;
	}
	
/*******************************************************************************************/
	/*
	 * This method of DAO will update the Employee from the DataBase using ID
	 * 
	 * */
	@Override
	public void updateEmployee(Employee emp) {
		
		entitymanager.merge(emp);
		entitymanager.flush();
	}

}














